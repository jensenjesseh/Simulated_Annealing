README instructions for project build

1. Unzip files
2. Open bash terminal
3. Using GNU Chain Compiler: enter 'g++ SimAnneal.cpp' to compile project
4. Ensure input text files are in working directory
5. To run program, enter './a.out input.txt output.txt'

